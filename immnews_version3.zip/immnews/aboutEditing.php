<?php session_start();

$userid=$_SESSION['userId']; 
$username=$_SESSION['username'];

//abouediting.php?userId=5
//Show the information to edit and have an edit button
//Show the information to edit and have an edit button


	include("includes/db-config.php");

	$stmt = $pdo->prepare("SELECT * FROM `article` WHERE `category` = 'A'");

	$stmt->execute();

	$row = $stmt->fetch();
	//echo("SELECT * FROM `article` WHERE `category` = 'A'");
	//echo($row["content"]);

?>


<!!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<title>IMM News Network - edit about</title>
		<meta name="keywords" content="imm ,news network, industry, industry,Technical,Career" />
		<meta name="description" content="imm news network, brainstorm, leading technologies" />
		<meta name="copyright" content="YAN ZHANG">
		<link href="css/main.css" rel="stylesheet">

		<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">

		<link rel="apple-touch-icon" sizes="180x180" href="./favicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="./favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="./favicon/favicon-16x16.png">
		<link rel="manifest" href="./favicon/site.webmanifest">
		<link rel="mask-icon" href="./favicon/safari-pinned-tab.svg" color="#5bbad5">
		<meta name="msapplication-TileColor" content="#da532c">
		<meta name="theme-color" content="#ffffff">
	</head> 

	
<body>

	<div>

		<header>
		      <img class="logo" src="images/logo.png" alt="IMM News Network" >
		      </img>
					<!--<h1>IMM News Network</h1>
		                 <i>The latest Interactive Media news and breaking technologies </i>
		 			<br></br>-->
		     <nav id="nav" width=100%>
		      	<ul>
		            <li><a href="immnewsnetwork.html"   class="texts" width=20% align=left ><b>home</b></a></li>
		            <li><a href="about.html"  class="texts" width=15% align=left ><b>about</b></a></li>
		            <li><a href="contact.html"  class="texts" width=15% align=left ><b>contact</b></a></li>
		             <li><a href="index.html" class="texts" width=15% align=left><b>member</b></a></li>
		        </ul>
		     </nav>
		</header>

		
		<section class="texts" >
				<h2><center>Edit about content</center></h2>
		 </section>

		<section>

			<form action="aboutEditingProcessing.php" enctype='multipart/form-data' method="POST">
					<p></p>
					<table align="center"  width=60% height=60%  bgcolor="lightgrey"  padding=5px margin=5px>
						<tr style="text-align:center;font-weight:bold; font-size: 12px">
							<td align= right class="texts" valign=top>
							<label for="info"> Last modified on <?php echo($row["lastModified"])?> by <?php echo($row["author"]);?> &nbsp;
							</label>
							</td>
						</tr>
						<tr>
							
							<td class="texts"  align=left>
							<textarea  rows="30" cols="80" name="content"   width=60% align=center style="font-size: 18px;" value="<?php echo($row['content']);?>"><?php echo($row['content']);?>
								
							</textarea>
							</td>
						</tr>

						<tr>
							<td colspan="2">&nbsp;</td>
						</tr>
						<tr>
							<td colspan="2" style="text-align:center;font-weight:bold; ">
							<input type="submit" value="UPDATE CONTENT" />
						</td>
						</tr>





						<tr>
							<td colspan="2">&nbsp;</td>
						</tr>


					</table>

				</form>

				

		</section>

		<footer>

			<p>
				<a href="loginVipResponse.php"  class="readmore" align=left >Back to admin log in&gt;&gt;</a> &nbsp;&nbsp;&nbsp;&nbsp;
				<a href="#" class="readmore" align=right>Accept Cookies</a> 
				&copy: 2020 IMM News Network
			</p>

		</footer>


	</div>

</body>



</html>