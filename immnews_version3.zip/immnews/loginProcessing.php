<?php session_start();
//process-login.php
$account = $_POST['account'];
$password = $_POST['password'];
//$userid=$_SESSION['userId'];

/**
Check the database for proper login info
If proper login info is found (username and password match),
then remember this user and consider the user logged-in.
*/
include('includes/db-config.php');

$stmt = $pdo->prepare("SELECT * FROM `user` 
	WHERE (`username` = '$account' OR `email`='$account')
	AND `password` = '$password'
	");

$stmt->execute();

$row = $stmt->fetch();
if($row){
	//S$loginresp="sucessfully logged in !";
	//echo("your username and password matches! You are now logged in.");
	$_SESSION['userId'] = $row['userId'];
	$_SESSION['username'] = $row['username'];
	$userId=$_SESSION['userId'];

	if ($row['typeId'] == 0) {

		header("Location: loginVipResponse.php?userId=$userId");

	} elseif ($row['typeId'] == 1) {

	    header("Location: loginResponse.php?userId=$userId");

	
	} else {

	//S$loginresp="wrong account/password, please check!";
	 header("Location: loginResponsefail.html");
	}
};



?>