<?php
//db-config.php

$dsn = "mysql:host=localhost;dbname=zhang78_immnews;charset=utf8mb4";
$dbusername = "zhang78_immnewsadmin";
$dbpassword = "0DwEdA6prm3XDSWk";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

?>