<?php 
//header.php
?>
<nav>
	<a href="index.php">Home</a> - 
	<a href="show-users.php">Show Users</a> - 
	<a href="show-games.php">Show Games</a> 
</nav>
<hr>